export interface Hero {
  id: number;
  name: string;
}

export interface Token {
  name: string;
}
