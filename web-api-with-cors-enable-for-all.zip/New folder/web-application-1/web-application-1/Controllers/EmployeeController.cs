﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;

namespace web_application_1.Controllers
{
    [Route("api/employee")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        // GET api/values/5
        [HttpGet("gethero")]
        public ActionResult<string> Get()
        {
            List<Hero> hrs = new List<Hero>();
            Hero h = new Hero();
            h.Id = 1;
            h.Name = "Chandra Prakash";

            hrs.Add(h);

            h = new Hero();
            h.Id = 2;
            h.Name = "Mayank";

            hrs.Add(h);

            return Ok(hrs);
        }

        [HttpGet("gettoken")]
        public ActionResult<string> GetToken()
        {
            Token token = new Token();
            token.Name = "xxxtoken";
            return Ok(token);
        }
    }

    public class Token
    {
        public string Name { get; set; }
    }

    public class Hero
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
